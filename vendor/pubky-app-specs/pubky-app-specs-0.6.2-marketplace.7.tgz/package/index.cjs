/* @ts-self-types="./pubky_app_specs.d.ts" */

class BlobResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(BlobResult.prototype);
        obj.__wbg_ptr = ptr;
        BlobResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BlobResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_blobresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyAppBlob}
     */
    get blob() {
        const ret = wasm.blobresult_blob(this.__wbg_ptr);
        return PubkyAppBlob.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.blobresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) BlobResult.prototype[Symbol.dispose] = BlobResult.prototype.free;
exports.BlobResult = BlobResult;

class BookmarkResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(BookmarkResult.prototype);
        obj.__wbg_ptr = ptr;
        BookmarkResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BookmarkResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_bookmarkresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyAppBookmark}
     */
    get bookmark() {
        const ret = wasm.bookmarkresult_bookmark(this.__wbg_ptr);
        return PubkyAppBookmark.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.bookmarkresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) BookmarkResult.prototype[Symbol.dispose] = BookmarkResult.prototype.free;
exports.BookmarkResult = BookmarkResult;

class FeedResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(FeedResult.prototype);
        obj.__wbg_ptr = ptr;
        FeedResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FeedResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_feedresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyAppFeed}
     */
    get feed() {
        const ret = wasm.feedresult_feed(this.__wbg_ptr);
        return PubkyAppFeed.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.feedresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) FeedResult.prototype[Symbol.dispose] = FeedResult.prototype.free;
exports.FeedResult = FeedResult;

class FileResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(FileResult.prototype);
        obj.__wbg_ptr = ptr;
        FileResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FileResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fileresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyAppFile}
     */
    get file() {
        const ret = wasm.fileresult_file(this.__wbg_ptr);
        return PubkyAppFile.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.fileresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) FileResult.prototype[Symbol.dispose] = FileResult.prototype.free;
exports.FileResult = FileResult;

class FollowResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(FollowResult.prototype);
        obj.__wbg_ptr = ptr;
        FollowResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FollowResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_followresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyAppFollow}
     */
    get follow() {
        const ret = wasm.followresult_follow(this.__wbg_ptr);
        return PubkyAppFollow.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.followresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) FollowResult.prototype[Symbol.dispose] = FollowResult.prototype.free;
exports.FollowResult = FollowResult;

class LastReadResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LastReadResult.prototype);
        obj.__wbg_ptr = ptr;
        LastReadResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LastReadResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_lastreadresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyAppLastRead}
     */
    get last_read() {
        const ret = wasm.lastreadresult_last_read(this.__wbg_ptr);
        return PubkyAppLastRead.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.lastreadresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) LastReadResult.prototype[Symbol.dispose] = LastReadResult.prototype.free;
exports.LastReadResult = LastReadResult;

class ListingResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ListingResult.prototype);
        obj.__wbg_ptr = ptr;
        ListingResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ListingResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_listingresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyAppListing}
     */
    get listing() {
        const ret = wasm.listingresult_listing(this.__wbg_ptr);
        return PubkyAppListing.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.listingresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) ListingResult.prototype[Symbol.dispose] = ListingResult.prototype.free;
exports.ListingResult = ListingResult;

class MarketplaceOrderReceiptResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(MarketplaceOrderReceiptResult.prototype);
        obj.__wbg_ptr = ptr;
        MarketplaceOrderReceiptResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MarketplaceOrderReceiptResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_marketplaceorderreceiptresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.marketplaceorderreceiptresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyAppMarketplaceOrderReceipt}
     */
    get order_receipt() {
        const ret = wasm.marketplaceorderreceiptresult_order_receipt(this.__wbg_ptr);
        return PubkyAppMarketplaceOrderReceipt.__wrap(ret);
    }
}
if (Symbol.dispose) MarketplaceOrderReceiptResult.prototype[Symbol.dispose] = MarketplaceOrderReceiptResult.prototype.free;
exports.MarketplaceOrderReceiptResult = MarketplaceOrderReceiptResult;

class MarketplaceReviewResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(MarketplaceReviewResult.prototype);
        obj.__wbg_ptr = ptr;
        MarketplaceReviewResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MarketplaceReviewResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_marketplacereviewresult_free(ptr, 0);
    }
    /**
     * @returns {PubkyAppMarketplaceReview}
     */
    get marketplace_review() {
        const ret = wasm.marketplacereviewresult_marketplace_review(this.__wbg_ptr);
        return PubkyAppMarketplaceReview.__wrap(ret);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.marketplacereviewresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
}
if (Symbol.dispose) MarketplaceReviewResult.prototype[Symbol.dispose] = MarketplaceReviewResult.prototype.free;
exports.MarketplaceReviewResult = MarketplaceReviewResult;

class Meta {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Meta.prototype);
        obj.__wbg_ptr = ptr;
        MetaFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MetaFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_meta_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    get id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.meta_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get path() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.meta_path(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get url() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.meta_url(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) Meta.prototype[Symbol.dispose] = Meta.prototype.free;
exports.Meta = Meta;

class MuteResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(MuteResult.prototype);
        obj.__wbg_ptr = ptr;
        MuteResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MuteResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_muteresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.muteresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyAppMute}
     */
    get mute() {
        const ret = wasm.muteresult_mute(this.__wbg_ptr);
        return PubkyAppMute.__wrap(ret);
    }
}
if (Symbol.dispose) MuteResult.prototype[Symbol.dispose] = MuteResult.prototype.free;
exports.MuteResult = MuteResult;

/**
 * This object represents the result of parsing a Pubky URI. It contains:
 * - `user_id`: the parsed user ID as a string.
 * - `resource`: a string representing the kind of resource (derived from internal `Resource` enum Display).
 * - `resource_id`: an optional resource identifier (if applicable).
 */
class ParsedUriResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ParsedUriResult.prototype);
        obj.__wbg_ptr = ptr;
        ParsedUriResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ParsedUriResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_parseduriresult_free(ptr, 0);
    }
    /**
     * Returns the resource kind.
     * @returns {string}
     */
    get resource() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.parseduriresult_resource(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Returns the resource ID if present.
     * @returns {string | undefined}
     */
    get resource_id() {
        const ret = wasm.parseduriresult_resource_id(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * Returns the user ID.
     * @returns {string}
     */
    get user_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.parseduriresult_user_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) ParsedUriResult.prototype[Symbol.dispose] = ParsedUriResult.prototype.free;
exports.ParsedUriResult = ParsedUriResult;

class PostResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PostResult.prototype);
        obj.__wbg_ptr = ptr;
        PostResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PostResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_postresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.postresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyAppPost}
     */
    get post() {
        const ret = wasm.postresult_post(this.__wbg_ptr);
        return PubkyAppPost.__wrap(ret);
    }
}
if (Symbol.dispose) PostResult.prototype[Symbol.dispose] = PostResult.prototype.free;
exports.PostResult = PostResult;

/**
 * Represents a blob, which backs a file uploaded by the user.
 * URI: /pub/pubky.app/blobs/:blob_id
 */
class PubkyAppBlob {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppBlob.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppBlobFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppBlobFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappblob_free(ptr, 0);
    }
    /**
     * Getter for the blob data as a `Uint8Array`.
     * @returns {Uint8Array}
     */
    get data() {
        const ret = wasm.pubkyappblob_data(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppBlob}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappblob_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppBlob.__wrap(ret[0]);
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappblob_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) PubkyAppBlob.prototype[Symbol.dispose] = PubkyAppBlob.prototype.free;
exports.PubkyAppBlob = PubkyAppBlob;

/**
 * Represents raw homeserver bookmark with id
 * URI: /pub/pubky.app/bookmarks/:bookmark_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/bookmarks/AF7KQ6NEV5XV1EG5DVJ2E74JJ4`
 *
 * Where bookmark_id is Crockford-base32(Blake3("{uri_bookmarked}"")[:half])
 */
class PubkyAppBookmark {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppBookmark.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppBookmarkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppBookmarkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappbookmark_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get created_at() {
        const ret = wasm.__wbg_get_pubkyappbookmark_created_at(this.__wbg_ptr);
        return ret;
    }
    /**
     * Serialize to JSON for WASM.
     * @param {any} js_value
     * @returns {PubkyAppBookmark}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappbookmark_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppBookmark.__wrap(ret[0]);
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappbookmark_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Getter for `uri`.
     * @returns {string}
     */
    get uri() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappbookmark_uri(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {bigint} arg0
     */
    set created_at(arg0) {
        wasm.__wbg_set_pubkyappbookmark_created_at(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppBookmark.prototype[Symbol.dispose] = PubkyAppBookmark.prototype.free;
exports.PubkyAppBookmark = PubkyAppBookmark;

/**
 * Represents a feed configuration.
 */
class PubkyAppFeed {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppFeed.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppFeedFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppFeedFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappfeed_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get created_at() {
        const ret = wasm.__wbg_get_pubkyappfeed_created_at(this.__wbg_ptr);
        return ret;
    }
    /**
     * Getter for `feed`.
     * @returns {PubkyAppFeedConfig}
     */
    get feed() {
        const ret = wasm.pubkyappfeed_feed(this.__wbg_ptr);
        return PubkyAppFeedConfig.__wrap(ret);
    }
    /**
     * Serialize to JSON for WASM.
     * @param {any} js_value
     * @returns {PubkyAppFeed}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappfeed_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppFeed.__wrap(ret[0]);
    }
    /**
     * Getter for `name`.
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappfeed_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappfeed_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {bigint} arg0
     */
    set created_at(arg0) {
        wasm.__wbg_set_pubkyappfeed_created_at(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppFeed.prototype[Symbol.dispose] = PubkyAppFeed.prototype.free;
exports.PubkyAppFeed = PubkyAppFeed;

/**
 * Configuration object for the feed.
 */
class PubkyAppFeedConfig {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppFeedConfig.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppFeedConfigFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppFeedConfigFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappfeedconfig_free(ptr, 0);
    }
    /**
     * Getter for `content`.
     * @returns {PubkyAppPostKind | undefined}
     */
    get content() {
        const ret = wasm.pubkyappfeedconfig_content(this.__wbg_ptr);
        return ret === 8 ? undefined : ret;
    }
    /**
     * Getter for `domain_tags`.
     * @returns {string[] | undefined}
     */
    get domain_tags() {
        const ret = wasm.pubkyappfeedconfig_domain_tags(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        }
        return v1;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppFeedConfig}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappfeedconfig_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppFeedConfig.__wrap(ret[0]);
    }
    /**
     * Getter for `layout`.
     * @returns {PubkyAppFeedLayout}
     */
    get layout() {
        const ret = wasm.pubkyappfeedconfig_layout(this.__wbg_ptr);
        return ret;
    }
    /**
     * Getter for `name`.
     * @returns {PubkyAppFeedReach}
     */
    get reach() {
        const ret = wasm.pubkyappfeedconfig_reach(this.__wbg_ptr);
        return ret;
    }
    /**
     * Getter for `sort`.
     * @returns {PubkyAppFeedSort}
     */
    get sort() {
        const ret = wasm.pubkyappfeedconfig_sort(this.__wbg_ptr);
        return ret;
    }
    /**
     * Getter for `tags`.
     * @returns {string[] | undefined}
     */
    get tags() {
        const ret = wasm.pubkyappfeedconfig_tags(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        }
        return v1;
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappfeedconfig_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) PubkyAppFeedConfig.prototype[Symbol.dispose] = PubkyAppFeedConfig.prototype.free;
exports.PubkyAppFeedConfig = PubkyAppFeedConfig;

/**
 * Enum representing the layout of the feed.
 * @enum {0 | 1 | 2 | 3}
 */
const PubkyAppFeedLayout = Object.freeze({
    Columns: 0, "0": "Columns",
    Wide: 1, "1": "Wide",
    Visual: 2, "2": "Visual",
    List: 3, "3": "List",
});
exports.PubkyAppFeedLayout = PubkyAppFeedLayout;

/**
 * Enum representing the reach of the feed.
 * @enum {0 | 1 | 2 | 3 | 4 | 5}
 */
const PubkyAppFeedReach = Object.freeze({
    Following: 0, "0": "Following",
    Followers: 1, "1": "Followers",
    Friends: 2, "2": "Friends",
    All: 3, "3": "All",
    Wot: 4, "4": "Wot",
    Me: 5, "5": "Me",
});
exports.PubkyAppFeedReach = PubkyAppFeedReach;

/**
 * Enum representing the sort order of the feed.
 * @enum {0 | 1}
 */
const PubkyAppFeedSort = Object.freeze({
    Recent: 0, "0": "Recent",
    Popularity: 1, "1": "Popularity",
});
exports.PubkyAppFeedSort = PubkyAppFeedSort;

/**
 * Represents a file uploaded by the user.
 * URI: /pub/pubky.app/files/:file_id
 */
class PubkyAppFile {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppFile.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppFileFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppFileFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappfile_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get created_at() {
        const ret = wasm.__wbg_get_pubkyappfile_created_at(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get size() {
        const ret = wasm.__wbg_get_pubkyappfile_size(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {string}
     */
    get content_type() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappfile_content_type(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppFile}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappfile_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppFile.__wrap(ret[0]);
    }
    /**
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappfile_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get src() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappfile_src(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappfile_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {bigint} arg0
     */
    set created_at(arg0) {
        wasm.__wbg_set_pubkyappfile_created_at(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set size(arg0) {
        wasm.__wbg_set_pubkyappfile_size(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppFile.prototype[Symbol.dispose] = PubkyAppFile.prototype.free;
exports.PubkyAppFile = PubkyAppFile;

/**
 * Represents raw homeserver follow object with timestamp
 *
 * On follow objects, the main data is encoded in the path
 *
 * URI: /pub/pubky.app/follows/:user_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/follows/pxnu33x7jtpx9ar1ytsi4yxbp6a5o36gwhffs8zoxmbuptici1jy`
 */
class PubkyAppFollow {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppFollow.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppFollowFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppFollowFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappfollow_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get created_at() {
        const ret = wasm.__wbg_get_pubkyappfollow_created_at(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppFollow}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappfollow_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppFollow.__wrap(ret[0]);
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappfollow_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {bigint} arg0
     */
    set created_at(arg0) {
        wasm.__wbg_set_pubkyappfollow_created_at(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppFollow.prototype[Symbol.dispose] = PubkyAppFollow.prototype.free;
exports.PubkyAppFollow = PubkyAppFollow;

/**
 * How the item can be delivered to the buyer.
 * @enum {0 | 1 | 2}
 */
const PubkyAppFulfillmentMethod = Object.freeze({
    Physical: 0, "0": "Physical",
    Digital: 1, "1": "Digital",
    Pickup: 2, "2": "Pickup",
});
exports.PubkyAppFulfillmentMethod = PubkyAppFulfillmentMethod;

/**
 * Represents the last read timestamp for notifications.
 * URI: /pub/pubky.app/last_read
 */
class PubkyAppLastRead {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppLastRead.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppLastReadFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppLastReadFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyapplastread_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get timestamp() {
        const ret = wasm.__wbg_get_pubkyapplastread_timestamp(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppLastRead}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyapplastread_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppLastRead.__wrap(ret[0]);
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyapplastread_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {bigint} arg0
     */
    set timestamp(arg0) {
        wasm.__wbg_set_pubkyapplastread_timestamp(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppLastRead.prototype[Symbol.dispose] = PubkyAppLastRead.prototype.free;
exports.PubkyAppLastRead = PubkyAppLastRead;

/**
 * Represents a marketplace listing published by a seller.
 *
 * URI: /pub/pubky.app/marketplace/v1/listings/:listing_id
 *
 * Where listing_id is Crockford-base32 encoding of a timestamp and must
 * match the record's `listingId` field.
 */
class PubkyAppListing {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppListing.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppListingFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppListingFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyapplisting_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    get adult_only() {
        const ret = wasm.__wbg_get_pubkyapplisting_adult_only(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkyapplisting_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkyapplisting_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace category taxonomy version, `1` or greater. The category
     * tree and the attribute expectations per category are versioned CLIENT
     * configuration keyed by this number — the record stays self-describing
     * without the spec churning per category.
     * @returns {bigint}
     */
    get taxonomy_version() {
        const ret = wasm.__wbg_get_pubkyapplisting_taxonomy_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * Getter for `description`.
     * @returns {string}
     */
    get description() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapplisting_description(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppListing}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyapplisting_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppListing.__wrap(ret[0]);
    }
    /**
     * Getter for `listing_id`.
     * @returns {string}
     */
    get listing_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapplisting_listing_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `owner_pubky`.
     * @returns {string}
     */
    get owner_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapplisting_owner_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `title`.
     * @returns {string}
     */
    get title() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapplisting_title(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyapplisting_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {boolean} arg0
     */
    set adult_only(arg0) {
        wasm.__wbg_set_pubkyapplisting_adult_only(this.__wbg_ptr, arg0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkyapplisting_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkyapplisting_schema_version(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace category taxonomy version, `1` or greater. The category
     * tree and the attribute expectations per category are versioned CLIENT
     * configuration keyed by this number — the record stays self-describing
     * without the spec churning per category.
     * @param {bigint} arg0
     */
    set taxonomy_version(arg0) {
        wasm.__wbg_set_pubkyapplisting_taxonomy_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppListing.prototype[Symbol.dispose] = PubkyAppListing.prototype.free;
exports.PubkyAppListing = PubkyAppListing;

/**
 * Physical condition of the listed item.
 * @enum {0 | 1 | 2 | 3 | 4 | 5}
 */
const PubkyAppListingCondition = Object.freeze({
    New: 0, "0": "New",
    LikeNew: 1, "1": "LikeNew",
    Excellent: 2, "2": "Excellent",
    Good: 3, "3": "Good",
    Fair: 4, "4": "Fair",
    ForParts: 5, "5": "ForParts",
});
exports.PubkyAppListingCondition = PubkyAppListingCondition;

/**
 * Media attachment type.
 * @enum {0 | 1}
 */
const PubkyAppListingMediaKind = Object.freeze({
    Image: 0, "0": "Image",
    Video: 1, "1": "Video",
});
exports.PubkyAppListingMediaKind = PubkyAppListingMediaKind;

/**
 * Lifecycle state of a marketplace listing.
 * @enum {0 | 1 | 2 | 3}
 */
const PubkyAppListingState = Object.freeze({
    Active: 0, "0": "Active",
    Paused: 1, "1": "Paused",
    Ended: 2, "2": "Ended",
    Removed: 3, "3": "Removed",
});
exports.PubkyAppListingState = PubkyAppListingState;

/**
 * Coarse public location attached to shops and listings.
 */
class PubkyAppMarketplaceLocation {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppMarketplaceLocationFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappmarketplacelocation_free(ptr, 0);
    }
}
if (Symbol.dispose) PubkyAppMarketplaceLocation.prototype[Symbol.dispose] = PubkyAppMarketplaceLocation.prototype.free;
exports.PubkyAppMarketplaceLocation = PubkyAppMarketplaceLocation;

/**
 * A PRIVATE portable order receipt — the buyer's or seller's own durable
 * copy of a completed order, written to their OWN homeserver.
 *
 * URI: /priv/pubky.app/marketplace/v1/receipts/:receipt_id
 *
 * The marketplace transaction service holds the canonical order state, but
 * a service is an operator that can disappear. This record is the credible
 * exit for orders: each party keeps a signed, self-contained receipt (the
 * embedded `receiptAttestation` JWS is offline-verifiable — see
 * `order_receipt_attestation.rs`) on storage they control, so a purchase
 * history survives the operator.
 *
 * Like the watchlist, this is a `/priv/` record: an order history reveals
 * counterparties, amounts, and purchase timing, so it must never be
 * world-readable, directory-listable, or Nexus-indexable. It is therefore
 * deliberately NOT wired into `PubkyAppObject` / the URI parser used by
 * watchers and indexers: nothing under `/priv/` is index-visible, and this
 * record only ever travels between the owner's own sessions.
 *
 * Unlike the watchlist singleton, receipts are one record per order under
 * `receipts/:receipt_id` (the service's receipt UUID): receipts are
 * immutable facts, not merge targets, and per-id paths let a client sync
 * incrementally instead of rewriting one growing document.
 */
class PubkyAppMarketplaceOrderReceipt {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppMarketplaceOrderReceipt.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppMarketplaceOrderReceiptFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppMarketplaceOrderReceiptFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappmarketplaceorderreceipt_free(ptr, 0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkyappmarketplaceorderreceipt_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkyappmarketplaceorderreceipt_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppMarketplaceOrderReceipt}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappmarketplaceorderreceipt_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppMarketplaceOrderReceipt.__wrap(ret[0]);
    }
    /**
     * Getter for `order_id`.
     * @returns {string}
     */
    get order_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappmarketplaceorderreceipt_order_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `owner_pubky`.
     * @returns {string}
     */
    get owner_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappmarketplaceorderreceipt_owner_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `receipt_id`.
     * @returns {string}
     */
    get receipt_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappmarketplaceorderreceipt_receipt_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappmarketplaceorderreceipt_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkyappmarketplaceorderreceipt_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkyappmarketplaceorderreceipt_schema_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppMarketplaceOrderReceipt.prototype[Symbol.dispose] = PubkyAppMarketplaceOrderReceipt.prototype.free;
exports.PubkyAppMarketplaceOrderReceipt = PubkyAppMarketplaceOrderReceipt;

/**
 * Represents a marketplace review of a trade counterparty.
 *
 * URI: /pub/pubky.app/marketplace/v1/reviews/:review_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/marketplace/v1/reviews/FPB0AM9S93Q3M1GFY1KV09GMQM`
 *
 * Where review_id is
 * Crockford-base32(Blake3("{reviewed_listing_uri}:{subject_pubky}:{role}")[:half])
 * and must match the record's `reviewId` field.
 */
class PubkyAppMarketplaceReview {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppMarketplaceReview.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppMarketplaceReviewFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppMarketplaceReviewFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappmarketplacereview_free(ptr, 0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkyappmarketplacereview_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkyappmarketplacereview_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppMarketplaceReview}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappmarketplacereview_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppMarketplaceReview.__wrap(ret[0]);
    }
    /**
     * Getter for `listing_id`.
     * @returns {string}
     */
    get listing_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappmarketplacereview_listing_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `subject_pubky`.
     * @returns {string}
     */
    get subject_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappmarketplacereview_subject_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `text`.
     * @returns {string}
     */
    get text() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappmarketplacereview_text(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappmarketplacereview_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkyappmarketplacereview_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkyappmarketplacereview_schema_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppMarketplaceReview.prototype[Symbol.dispose] = PubkyAppMarketplaceReview.prototype.free;
exports.PubkyAppMarketplaceReview = PubkyAppMarketplaceReview;

/**
 * Integer money in minor units, e.g. cents or satoshis.
 *
 * `amount_minor` is always an integer amount of the smallest unit,
 * `currency` is an uppercase asset code and `exponent` the number of
 * decimal places between minor and major units.
 */
class PubkyAppMoney {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppMoneyFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappmoney_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get amount_minor() {
        const ret = wasm.__wbg_get_pubkyappmoney_amount_minor(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get exponent() {
        const ret = wasm.__wbg_get_pubkyappmoney_exponent(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {bigint} arg0
     */
    set amount_minor(arg0) {
        wasm.__wbg_set_pubkyappmoney_amount_minor(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set exponent(arg0) {
        wasm.__wbg_set_pubkyappmoney_exponent(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppMoney.prototype[Symbol.dispose] = PubkyAppMoney.prototype.free;
exports.PubkyAppMoney = PubkyAppMoney;

/**
 * Represents raw homeserver Mute object with timestamp
 * URI: /pub/pubky.app/mutes/:user_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/mutes/pxnu33x7jtpx9ar1ytsi4yxbp6a5o36gwhffs8zoxmbuptici1jy`
 */
class PubkyAppMute {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppMute.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppMuteFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppMuteFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappmute_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get created_at() {
        const ret = wasm.__wbg_get_pubkyappmute_created_at(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppMute}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappmute_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppMute.__wrap(ret[0]);
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappmute_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {bigint} arg0
     */
    set created_at(arg0) {
        wasm.__wbg_set_pubkyappmute_created_at(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppMute.prototype[Symbol.dispose] = PubkyAppMute.prototype.free;
exports.PubkyAppMute = PubkyAppMute;

/**
 * The record owner's side of the order.
 * @enum {0 | 1}
 */
const PubkyAppOrderReceiptRole = Object.freeze({
    Buyer: 0, "0": "Buyer",
    Seller: 1, "1": "Seller",
});
exports.PubkyAppOrderReceiptRole = PubkyAppOrderReceiptRole;

/**
 * Represents raw post in homeserver with content and kind
 * URI: /pub/pubky.app/posts/:post_id
 * Where post_id is CrockfordBase32 encoding of timestamp
 *
 * Example URI:
 *
 * `/pub/pubky.app/posts/00321FCW75ZFY`
 */
class PubkyAppPost {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppPost.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppPostFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppPostFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyapppost_free(ptr, 0);
    }
    /**
     * @returns {string[] | undefined}
     */
    get attachments() {
        const ret = wasm.pubkyapppost_attachments(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        }
        return v1;
    }
    /**
     * @returns {string}
     */
    get content() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapppost_content(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {PubkyAppPostEmbed | undefined}
     */
    get embed() {
        const ret = wasm.pubkyapppost_embed(this.__wbg_ptr);
        return ret === 0 ? undefined : PubkyAppPostEmbed.__wrap(ret);
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppPost}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyapppost_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppPost.__wrap(ret[0]);
    }
    /**
     * @returns {string}
     */
    get kind() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapppost_kind(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string | undefined}
     */
    get lock() {
        const ret = wasm.pubkyapppost_lock(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * Creates a new `PubkyAppPost` instance and sanitizes it.
     * @param {string} content
     * @param {PubkyAppPostKind} kind
     * @param {string | null} [parent]
     * @param {PubkyAppPostEmbed | null} [embed]
     * @param {string[] | null} [attachments]
     */
    constructor(content, kind, parent, embed, attachments) {
        const ptr0 = passStringToWasm0(content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(parent) ? 0 : passStringToWasm0(parent, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        let ptr2 = 0;
        if (!isLikeNone(embed)) {
            _assertClass(embed, PubkyAppPostEmbed);
            ptr2 = embed.__destroy_into_raw();
        }
        var ptr3 = isLikeNone(attachments) ? 0 : passArrayJsValueToWasm0(attachments, wasm.__wbindgen_malloc);
        var len3 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyapppost_new(ptr0, len0, kind, ptr1, len1, ptr2, ptr3, len3);
        this.__wbg_ptr = ret >>> 0;
        PubkyAppPostFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Creates a new lockable `PubkyAppPost` instance and sanitizes it.
     * @param {string} content
     * @param {PubkyAppPostKind} kind
     * @param {string | null} [parent]
     * @param {PubkyAppPostEmbed | null} [embed]
     * @param {string[] | null} [attachments]
     * @param {string | null} [lock]
     * @returns {PubkyAppPost}
     */
    static new_with_lock(content, kind, parent, embed, attachments, lock) {
        const ptr0 = passStringToWasm0(content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(parent) ? 0 : passStringToWasm0(parent, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        let ptr2 = 0;
        if (!isLikeNone(embed)) {
            _assertClass(embed, PubkyAppPostEmbed);
            ptr2 = embed.__destroy_into_raw();
        }
        var ptr3 = isLikeNone(attachments) ? 0 : passArrayJsValueToWasm0(attachments, wasm.__wbindgen_malloc);
        var len3 = WASM_VECTOR_LEN;
        var ptr4 = isLikeNone(lock) ? 0 : passStringToWasm0(lock, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len4 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyapppost_new_with_lock(ptr0, len0, kind, ptr1, len1, ptr2, ptr3, len3, ptr4, len4);
        return PubkyAppPost.__wrap(ret);
    }
    /**
     * @returns {string | undefined}
     */
    get parent() {
        const ret = wasm.pubkyapppost_parent(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyapppost_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) PubkyAppPost.prototype[Symbol.dispose] = PubkyAppPost.prototype.free;
exports.PubkyAppPost = PubkyAppPost;

/**
 * Represents embedded content within a post
 */
class PubkyAppPostEmbed {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppPostEmbed.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppPostEmbedFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppPostEmbedFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyapppostembed_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    get kind() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapppostembed_kind(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {string} uri
     * @param {PubkyAppPostKind} kind
     */
    constructor(uri, kind) {
        const ptr0 = passStringToWasm0(uri, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyapppostembed_new(ptr0, len0, kind);
        this.__wbg_ptr = ret >>> 0;
        PubkyAppPostEmbedFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {string}
     */
    get uri() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapppostembed_uri(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) PubkyAppPostEmbed.prototype[Symbol.dispose] = PubkyAppPostEmbed.prototype.free;
exports.PubkyAppPostEmbed = PubkyAppPostEmbed;

/**
 * Represents the type of pubky-app posted data
 * Used primarily to best display the content in UI
 * @enum {0 | 1 | 2 | 3 | 4 | 5 | 6 | 7}
 */
const PubkyAppPostKind = Object.freeze({
    Short: 0, "0": "Short",
    Long: 1, "1": "Long",
    Image: 2, "2": "Image",
    Video: 3, "3": "Video",
    Link: 4, "4": "Link",
    File: 5, "5": "File",
    Collection: 6, "6": "Collection",
    Unknown: 7, "7": "Unknown",
});
exports.PubkyAppPostKind = PubkyAppPostKind;

/**
 * Star ratings on a 1-5 integer scale. Only `overall` is required.
 */
class PubkyAppReviewRatings {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppReviewRatingsFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappreviewratings_free(ptr, 0);
    }
    /**
     * @returns {bigint | undefined}
     */
    get communication() {
        const ret = wasm.__wbg_get_pubkyappreviewratings_communication(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @returns {bigint | undefined}
     */
    get item_accuracy() {
        const ret = wasm.__wbg_get_pubkyappreviewratings_item_accuracy(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @returns {bigint}
     */
    get overall() {
        const ret = wasm.__wbg_get_pubkyappreviewratings_overall(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint | undefined}
     */
    get shipping() {
        const ret = wasm.__wbg_get_pubkyappreviewratings_shipping(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @param {bigint | null} [arg0]
     */
    set communication(arg0) {
        wasm.__wbg_set_pubkyappreviewratings_communication(this.__wbg_ptr, !isLikeNone(arg0), isLikeNone(arg0) ? BigInt(0) : arg0);
    }
    /**
     * @param {bigint | null} [arg0]
     */
    set item_accuracy(arg0) {
        wasm.__wbg_set_pubkyappreviewratings_item_accuracy(this.__wbg_ptr, !isLikeNone(arg0), isLikeNone(arg0) ? BigInt(0) : arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set overall(arg0) {
        wasm.__wbg_set_pubkyappreviewratings_overall(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint | null} [arg0]
     */
    set shipping(arg0) {
        wasm.__wbg_set_pubkyappreviewratings_shipping(this.__wbg_ptr, !isLikeNone(arg0), isLikeNone(arg0) ? BigInt(0) : arg0);
    }
}
if (Symbol.dispose) PubkyAppReviewRatings.prototype[Symbol.dispose] = PubkyAppReviewRatings.prototype.free;
exports.PubkyAppReviewRatings = PubkyAppReviewRatings;

/**
 * Represents a response to a marketplace review, published by the review's
 * subject on their own homeserver.
 *
 * URI: /pub/pubky.app/marketplace/v1/review_responses/:review_id
 *
 * The path ID **equals the subject review's ID**, which gives O(1) lookup
 * in both directions and structurally caps responses at one per review
 * (revisable via `revision`).
 *
 * Authorization is structural, not cryptographic: an indexer accepts a
 * response only when the response record's `owner_pubky` equals the
 * subject review's `subjectPubky` (see [`Self::is_authorized_response_to`]).
 * An impostor's response fails that check without any signature machinery.
 */
class PubkyAppReviewResponse {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppReviewResponse.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppReviewResponseFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppReviewResponseFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappreviewresponse_free(ptr, 0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkyappreviewresponse_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkyappreviewresponse_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppReviewResponse}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappreviewresponse_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppReviewResponse.__wrap(ret[0]);
    }
    /**
     * Getter for `review_id`.
     * @returns {string}
     */
    get review_id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappreviewresponse_review_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `review_uri`.
     * @returns {string}
     */
    get review_uri() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappreviewresponse_review_uri(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `text`.
     * @returns {string}
     */
    get text() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappreviewresponse_text(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappreviewresponse_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkyappreviewresponse_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkyappreviewresponse_schema_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppReviewResponse.prototype[Symbol.dispose] = PubkyAppReviewResponse.prototype.free;
exports.PubkyAppReviewResponse = PubkyAppReviewResponse;

/**
 * Which side of the trade the review covers.
 * @enum {0 | 1}
 */
const PubkyAppReviewRole = Object.freeze({
    BuyerReviewingSeller: 0, "0": "BuyerReviewingSeller",
    SellerReviewingBuyer: 1, "1": "SellerReviewingBuyer",
});
exports.PubkyAppReviewRole = PubkyAppReviewRole;

/**
 * Represents a seller's marketplace shop profile (singleton per user).
 *
 * URI: /pub/pubky.app/marketplace/v1/shop.json
 */
class PubkyAppShop {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppShop.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppShopFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppShopFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappshop_free(ptr, 0);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkyappshop_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkyappshop_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {boolean}
     */
    get vacation_mode() {
        const ret = wasm.__wbg_get_pubkyappshop_vacation_mode(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Getter for `bio`.
     * @returns {string}
     */
    get bio() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappshop_bio(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppShop}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappshop_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppShop.__wrap(ret[0]);
    }
    /**
     * Getter for `name`.
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappshop_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Getter for `owner_pubky`.
     * @returns {string}
     */
    get owner_pubky() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappshop_owner_pubky(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappshop_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing record revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkyappshop_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkyappshop_schema_version(this.__wbg_ptr, arg0);
    }
    /**
     * @param {boolean} arg0
     */
    set vacation_mode(arg0) {
        wasm.__wbg_set_pubkyappshop_vacation_mode(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppShop.prototype[Symbol.dispose] = PubkyAppShop.prototype.free;
exports.PubkyAppShop = PubkyAppShop;

/**
 * Represents raw homeserver tag with id
 * URI: /pub/pubky.app/tags/:tag_id
 *
 * Example URI:
 *
 * `/pub/pubky.app/tags/FPB0AM9S93Q3M1GFY1KV09GMQM`
 *
 * Where tag_id is Crockford-base32(Blake3("{uri_tagged}:{label}")[:half])
 */
class PubkyAppTag {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppTag.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppTagFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppTagFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyapptag_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get created_at() {
        const ret = wasm.__wbg_get_pubkyapptag_created_at(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppTag}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyapptag_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppTag.__wrap(ret[0]);
    }
    /**
     * Getter for `label`.
     * @returns {string}
     */
    get label() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapptag_label(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Serialize to JSON for WASM.
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyapptag_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Getter for `uri`.
     * @returns {string}
     */
    get uri() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyapptag_uri(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {bigint} arg0
     */
    set created_at(arg0) {
        wasm.__wbg_set_pubkyapptag_created_at(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppTag.prototype[Symbol.dispose] = PubkyAppTag.prototype.free;
exports.PubkyAppTag = PubkyAppTag;

/**
 * URI: /pub/pubky.app/profile.json
 */
class PubkyAppUser {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppUser.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppUserFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppUserFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappuser_free(ptr, 0);
    }
    /**
     * @returns {string | undefined}
     */
    get bio() {
        const ret = wasm.pubkyappuser_bio(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppUser}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappuser_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppUser.__wrap(ret[0]);
    }
    /**
     * @returns {string | undefined}
     */
    get image() {
        const ret = wasm.pubkyappuser_image(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @returns {PubkyAppUserLink[] | undefined}
     */
    get links() {
        const ret = wasm.pubkyappuser_links(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        }
        return v1;
    }
    /**
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappuser_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Creates a new `PubkyAppUser` instance and sanitizes it.
     * @param {string} name
     * @param {string | null} [bio]
     * @param {string | null} [image]
     * @param {PubkyAppUserLink[] | null} [links]
     * @param {string | null} [status]
     */
    constructor(name, bio, image, links, status) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(bio) ? 0 : passStringToWasm0(bio, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(image) ? 0 : passStringToWasm0(image, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        var ptr3 = isLikeNone(links) ? 0 : passArrayJsValueToWasm0(links, wasm.__wbindgen_malloc);
        var len3 = WASM_VECTOR_LEN;
        var ptr4 = isLikeNone(status) ? 0 : passStringToWasm0(status, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len4 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyappuser_new(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4);
        this.__wbg_ptr = ret >>> 0;
        PubkyAppUserFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {string | undefined}
     */
    get status() {
        const ret = wasm.pubkyappuser_status(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappuser_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) PubkyAppUser.prototype[Symbol.dispose] = PubkyAppUser.prototype.free;
exports.PubkyAppUser = PubkyAppUser;

/**
 * Represents a user's single link with a title and URL.
 */
class PubkyAppUserLink {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppUserLink.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppUserLinkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    static __unwrap(jsValue) {
        if (!(jsValue instanceof PubkyAppUserLink)) {
            return 0;
        }
        return jsValue.__destroy_into_raw();
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppUserLinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappuserlink_free(ptr, 0);
    }
    /**
     * Creates a new `PubkyAppUserLink` instance and sanitizes it.
     * @param {string} title
     * @param {string} url
     */
    constructor(title, url) {
        const ptr0 = passStringToWasm0(title, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyappuserlink_new(ptr0, len0, ptr1, len1);
        this.__wbg_ptr = ret >>> 0;
        PubkyAppUserLinkFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {string}
     */
    get title() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappuserlink_title(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get url() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.pubkyappuserlink_url(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) PubkyAppUserLink.prototype[Symbol.dispose] = PubkyAppUserLink.prototype.free;
exports.PubkyAppUserLink = PubkyAppUserLink;

/**
 * Represents a user's PRIVATE marketplace watchlist.
 *
 * URI: /priv/pubky.app/marketplace/v1/watchlist.json
 *
 * This is the first record under `/priv/` — the homeserver's authenticated
 * private storage (reads, listings, and writes by anyone but the owner's
 * session are refused). A watchlist reveals purchase intent, so unlike every
 * `/pub/pubky.app/` record it must not be world-readable, directory-listable,
 * or Nexus-indexable. It is therefore deliberately NOT wired into
 * `PubkyAppObject` / the URI parser used by watchers and indexers: nothing
 * under `/priv/` is index-visible, and this record only ever travels between
 * the owner's own sessions.
 *
 * It is a SINGLE revisioned document rather than one record per watched
 * listing because: (a) watch/unwatch toggles are high-churn and a single
 * document makes each sync one `PUT` instead of a create/delete stream;
 * (b) merge needs items and tombstones resolved together atomically — two
 * files could tear; and (c) private storage has no index to benefit from
 * per-item paths. Clients merge concurrent writers per entry
 * (last-write-wins on the entry's millisecond timestamp) and write back the
 * resolved document, in which each listing key appears in `items` or
 * `tombstones` but never both.
 */
class PubkyAppWatchlist {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PubkyAppWatchlist.prototype);
        obj.__wbg_ptr = ptr;
        PubkyAppWatchlistFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppWatchlistFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappwatchlist_free(ptr, 0);
    }
    /**
     * Monotonically increasing document revision, starting at 1.
     * @returns {bigint}
     */
    get revision() {
        const ret = wasm.__wbg_get_pubkyappwatchlist_revision(this.__wbg_ptr);
        return ret;
    }
    /**
     * Marketplace contract version, always `1`.
     * @returns {bigint}
     */
    get schema_version() {
        const ret = wasm.__wbg_get_pubkyappwatchlist_schema_version(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} js_value
     * @returns {PubkyAppWatchlist}
     */
    static fromJson(js_value) {
        const ret = wasm.pubkyappwatchlist_fromJson(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PubkyAppWatchlist.__wrap(ret[0]);
    }
    /**
     * @returns {any}
     */
    toJson() {
        const ret = wasm.pubkyappwatchlist_toJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Monotonically increasing document revision, starting at 1.
     * @param {bigint} arg0
     */
    set revision(arg0) {
        wasm.__wbg_set_pubkyappwatchlist_revision(this.__wbg_ptr, arg0);
    }
    /**
     * Marketplace contract version, always `1`.
     * @param {bigint} arg0
     */
    set schema_version(arg0) {
        wasm.__wbg_set_pubkyappwatchlist_schema_version(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppWatchlist.prototype[Symbol.dispose] = PubkyAppWatchlist.prototype.free;
exports.PubkyAppWatchlist = PubkyAppWatchlist;

/**
 * One actively watched listing.
 *
 * `watched_at_ms` is milliseconds since the UNIX epoch. Entry timestamps are
 * integers (not ISO-8601 strings like the document-level `createdAt` /
 * `updatedAt`) on purpose: they are last-write-wins merge keys that clients
 * compare numerically, and integer milliseconds cannot be skewed by
 * offset-formatting differences between writers.
 */
class PubkyAppWatchlistItem {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppWatchlistItemFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappwatchlistitem_free(ptr, 0);
    }
    /**
     * Milliseconds since the UNIX epoch when the watch was (re)asserted.
     * @returns {bigint}
     */
    get watched_at_ms() {
        const ret = wasm.__wbg_get_pubkyappwatchlistitem_watched_at_ms(this.__wbg_ptr);
        return ret;
    }
    /**
     * Milliseconds since the UNIX epoch when the watch was (re)asserted.
     * @param {bigint} arg0
     */
    set watched_at_ms(arg0) {
        wasm.__wbg_set_pubkyappwatchlistitem_watched_at_ms(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppWatchlistItem.prototype[Symbol.dispose] = PubkyAppWatchlistItem.prototype.free;
exports.PubkyAppWatchlistItem = PubkyAppWatchlistItem;

/**
 * A removed watch, retained so a delete wins over a stale re-add during merge.
 *
 * `removed_at_ms` is milliseconds since the UNIX epoch (see
 * [`PubkyAppWatchlistItem`] for why entry timestamps are integers).
 */
class PubkyAppWatchlistTombstone {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyAppWatchlistTombstoneFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyappwatchlisttombstone_free(ptr, 0);
    }
    /**
     * Milliseconds since the UNIX epoch when the watch was removed.
     * @returns {bigint}
     */
    get removed_at_ms() {
        const ret = wasm.__wbg_get_pubkyappwatchlisttombstone_removed_at_ms(this.__wbg_ptr);
        return ret;
    }
    /**
     * Milliseconds since the UNIX epoch when the watch was removed.
     * @param {bigint} arg0
     */
    set removed_at_ms(arg0) {
        wasm.__wbg_set_pubkyappwatchlisttombstone_removed_at_ms(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) PubkyAppWatchlistTombstone.prototype[Symbol.dispose] = PubkyAppWatchlistTombstone.prototype.free;
exports.PubkyAppWatchlistTombstone = PubkyAppWatchlistTombstone;

/**
 * Represents user data with name, bio, image, links, and status.
 */
class PubkyId {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkyIdFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyid_free(ptr, 0);
    }
}
if (Symbol.dispose) PubkyId.prototype[Symbol.dispose] = PubkyId.prototype.free;
exports.PubkyId = PubkyId;

/**
 * Represents a user's single link with a title and URL.
 */
class PubkySpecsBuilder {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PubkySpecsBuilderFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pubkyspecsbuilder_free(ptr, 0);
    }
    /**
     * @param {any} blob_data
     * @returns {BlobResult}
     */
    createBlob(blob_data) {
        const ret = wasm.pubkyspecsbuilder_createBlob(this.__wbg_ptr, blob_data);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BlobResult.__wrap(ret[0]);
    }
    /**
     * @param {string} uri
     * @returns {BookmarkResult}
     */
    createBookmark(uri) {
        const ptr0 = passStringToWasm0(uri, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_createBookmark(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BookmarkResult.__wrap(ret[0]);
    }
    /**
     * Creates a `kind = Collection` post — a curated list of URIs under
     * a name and optional description.
     *
     * Convenience wrapper around `createPost` that builds the
     * `PubkyAppCollectionContent` envelope (`{ name, description, items,
     * cover_image, layout }`) and JSON-serializes it into `content` internally,
     * so JS callers don't have to stringify the envelope themselves.
     *
     * `layout` is one of `"grid" | "list" | "visual"`.
     *
     * `parent` and `embed` are not supported for Collection posts — the
     * validator rejects them — so this helper omits those arguments.
     * @param {string} name
     * @param {string | null} [description]
     * @param {string[] | null} [items]
     * @param {string | null} [cover_image]
     * @param {string | null} [layout]
     * @returns {PostResult}
     */
    createCollectionPost(name, description, items, cover_image, layout) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(description) ? 0 : passStringToWasm0(description, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(items) ? 0 : passArrayJsValueToWasm0(items, wasm.__wbindgen_malloc);
        var len2 = WASM_VECTOR_LEN;
        var ptr3 = isLikeNone(cover_image) ? 0 : passStringToWasm0(cover_image, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len3 = WASM_VECTOR_LEN;
        var ptr4 = isLikeNone(layout) ? 0 : passStringToWasm0(layout, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len4 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_createCollectionPost(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PostResult.__wrap(ret[0]);
    }
    /**
     * @param {any} tags
     * @param {string} reach
     * @param {string} layout
     * @param {string} sort
     * @param {string | null | undefined} content
     * @param {string} name
     * @param {any} domain_tags
     * @returns {FeedResult}
     */
    createFeed(tags, reach, layout, sort, content, name, domain_tags) {
        const ptr0 = passStringToWasm0(reach, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(layout, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(sort, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        var ptr3 = isLikeNone(content) ? 0 : passStringToWasm0(content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len3 = WASM_VECTOR_LEN;
        const ptr4 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len4 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_createFeed(this.__wbg_ptr, tags, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4, domain_tags);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return FeedResult.__wrap(ret[0]);
    }
    /**
     * @param {string} name
     * @param {string} src
     * @param {string} content_type
     * @param {number} size
     * @returns {FileResult}
     */
    createFile(name, src, content_type, size) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(src, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(content_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_createFile(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, size);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return FileResult.__wrap(ret[0]);
    }
    /**
     * @param {string} followee_id
     * @returns {FollowResult}
     */
    createFollow(followee_id) {
        const ptr0 = passStringToWasm0(followee_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_createFollow(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return FollowResult.__wrap(ret[0]);
    }
    /**
     * @returns {LastReadResult}
     */
    createLastRead() {
        const ret = wasm.pubkyspecsbuilder_createLastRead(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LastReadResult.__wrap(ret[0]);
    }
    /**
     * Creates a listing record from a plain JSON object matching the
     * marketplace listing schema (camelCase fields). A fresh timestamp ID
     * is generated and written into the record's `listingId`.
     * @param {any} listing
     * @returns {ListingResult}
     */
    createListing(listing) {
        const ret = wasm.pubkyspecsbuilder_createListing(this.__wbg_ptr, listing);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ListingResult.__wrap(ret[0]);
    }
    /**
     * Creates a private order receipt record from a plain JSON object
     * matching the order receipt schema (camelCase fields). The path ID
     * equals the record's `receiptId` (the transaction service's receipt
     * UUID). The resulting path/url live under `/priv/pubky.app/` — only
     * the owner's authenticated sessions can read or write it.
     * @param {any} receipt
     * @returns {MarketplaceOrderReceiptResult}
     */
    createMarketplaceOrderReceipt(receipt) {
        const ret = wasm.pubkyspecsbuilder_createMarketplaceOrderReceipt(this.__wbg_ptr, receipt);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return MarketplaceOrderReceiptResult.__wrap(ret[0]);
    }
    /**
     * Creates a marketplace review record from a plain JSON object matching
     * the marketplace review schema (camelCase fields). The hash ID is
     * derived from the reviewed listing URI, subject, and role, and written
     * into the record's `reviewId`.
     * @param {any} review
     * @returns {MarketplaceReviewResult}
     */
    createMarketplaceReview(review) {
        const ret = wasm.pubkyspecsbuilder_createMarketplaceReview(this.__wbg_ptr, review);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return MarketplaceReviewResult.__wrap(ret[0]);
    }
    /**
     * @param {string} mutee_id
     * @returns {MuteResult}
     */
    createMute(mutee_id) {
        const ptr0 = passStringToWasm0(mutee_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_createMute(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return MuteResult.__wrap(ret[0]);
    }
    /**
     * Optional `lock`: `pubky://` URL with a host pointing at a lock server.
     * @param {string} content
     * @param {PubkyAppPostKind} kind
     * @param {string | null} [parent]
     * @param {PubkyAppPostEmbed | null} [embed]
     * @param {string[] | null} [attachments]
     * @param {string | null} [lock]
     * @returns {PostResult}
     */
    createPost(content, kind, parent, embed, attachments, lock) {
        const ptr0 = passStringToWasm0(content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(parent) ? 0 : passStringToWasm0(parent, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        let ptr2 = 0;
        if (!isLikeNone(embed)) {
            _assertClass(embed, PubkyAppPostEmbed);
            ptr2 = embed.__destroy_into_raw();
        }
        var ptr3 = isLikeNone(attachments) ? 0 : passArrayJsValueToWasm0(attachments, wasm.__wbindgen_malloc);
        var len3 = WASM_VECTOR_LEN;
        var ptr4 = isLikeNone(lock) ? 0 : passStringToWasm0(lock, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len4 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_createPost(this.__wbg_ptr, ptr0, len0, kind, ptr1, len1, ptr2, ptr3, len3, ptr4, len4);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PostResult.__wrap(ret[0]);
    }
    /**
     * Creates a review-response record from a plain JSON object matching
     * the review-response schema (camelCase fields). The path ID equals the
     * subject review's ID carried in the record's `reviewId`.
     * @param {any} response
     * @returns {ReviewResponseResult}
     */
    createReviewResponse(response) {
        const ret = wasm.pubkyspecsbuilder_createReviewResponse(this.__wbg_ptr, response);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ReviewResponseResult.__wrap(ret[0]);
    }
    /**
     * Creates a shop record from a plain JSON object matching the
     * marketplace shop schema (camelCase fields).
     * @param {any} shop
     * @returns {ShopResult}
     */
    createShop(shop) {
        const ret = wasm.pubkyspecsbuilder_createShop(this.__wbg_ptr, shop);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ShopResult.__wrap(ret[0]);
    }
    /**
     * @param {string} uri
     * @param {string} label
     * @returns {TagResult}
     */
    createTag(uri, label) {
        const ptr0 = passStringToWasm0(uri, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(label, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_createTag(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return TagResult.__wrap(ret[0]);
    }
    /**
     * @param {string} name
     * @param {string | null | undefined} bio
     * @param {string | null | undefined} image
     * @param {any} links
     * @param {string | null} [status]
     * @returns {UserResult}
     */
    createUser(name, bio, image, links, status) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(bio) ? 0 : passStringToWasm0(bio, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(image) ? 0 : passStringToWasm0(image, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        var ptr3 = isLikeNone(status) ? 0 : passStringToWasm0(status, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len3 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_createUser(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, links, ptr3, len3);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return UserResult.__wrap(ret[0]);
    }
    /**
     * Creates a private watchlist document from a plain JSON object matching
     * the watchlist schema (camelCase fields). The resulting path/url live
     * under `/priv/pubky.app/` — only the owner's authenticated sessions can
     * read or write it.
     * @param {any} watchlist
     * @returns {WatchlistResult}
     */
    createWatchlist(watchlist) {
        const ret = wasm.pubkyspecsbuilder_createWatchlist(this.__wbg_ptr, watchlist);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WatchlistResult.__wrap(ret[0]);
    }
    /**
     * Edits an existing post by updating its content while preserving its original ID and timestamp.
     * @param {PubkyAppPost} original_post
     * @param {string} post_id
     * @param {string} new_content
     * @returns {PostResult}
     */
    editPost(original_post, post_id, new_content) {
        _assertClass(original_post, PubkyAppPost);
        var ptr0 = original_post.__destroy_into_raw();
        const ptr1 = passStringToWasm0(post_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(new_content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_editPost(this.__wbg_ptr, ptr0, ptr1, len1, ptr2, len2);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return PostResult.__wrap(ret[0]);
    }
    /**
     * Creates a new `PubkyAppBuilder` instance.
     * @param {string} pubky_id
     */
    constructor(pubky_id) {
        const ptr0 = passStringToWasm0(pubky_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pubkyspecsbuilder_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        PubkySpecsBuilderFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Returns validation limits as a JSON value for client-side use.
     * @returns {any}
     */
    get validationLimits() {
        const ret = wasm.pubkyspecsbuilder_validationLimits(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) PubkySpecsBuilder.prototype[Symbol.dispose] = PubkySpecsBuilder.prototype.free;
exports.PubkySpecsBuilder = PubkySpecsBuilder;

class ReviewResponseResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ReviewResponseResult.prototype);
        obj.__wbg_ptr = ptr;
        ReviewResponseResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ReviewResponseResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_reviewresponseresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.reviewresponseresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyAppReviewResponse}
     */
    get review_response() {
        const ret = wasm.reviewresponseresult_review_response(this.__wbg_ptr);
        return PubkyAppReviewResponse.__wrap(ret);
    }
}
if (Symbol.dispose) ReviewResponseResult.prototype[Symbol.dispose] = ReviewResponseResult.prototype.free;
exports.ReviewResponseResult = ReviewResponseResult;

class ShopResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ShopResult.prototype);
        obj.__wbg_ptr = ptr;
        ShopResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ShopResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_shopresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.shopresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyAppShop}
     */
    get shop() {
        const ret = wasm.shopresult_shop(this.__wbg_ptr);
        return PubkyAppShop.__wrap(ret);
    }
}
if (Symbol.dispose) ShopResult.prototype[Symbol.dispose] = ShopResult.prototype.free;
exports.ShopResult = ShopResult;

class TagResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(TagResult.prototype);
        obj.__wbg_ptr = ptr;
        TagResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TagResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_tagresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.tagresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyAppTag}
     */
    get tag() {
        const ret = wasm.tagresult_tag(this.__wbg_ptr);
        return PubkyAppTag.__wrap(ret);
    }
}
if (Symbol.dispose) TagResult.prototype[Symbol.dispose] = TagResult.prototype.free;
exports.TagResult = TagResult;

class UserResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(UserResult.prototype);
        obj.__wbg_ptr = ptr;
        UserResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        UserResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_userresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.userresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyAppUser}
     */
    get user() {
        const ret = wasm.userresult_user(this.__wbg_ptr);
        return PubkyAppUser.__wrap(ret);
    }
}
if (Symbol.dispose) UserResult.prototype[Symbol.dispose] = UserResult.prototype.free;
exports.UserResult = UserResult;

class WatchlistResult {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WatchlistResult.prototype);
        obj.__wbg_ptr = ptr;
        WatchlistResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WatchlistResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_watchlistresult_free(ptr, 0);
    }
    /**
     * @returns {Meta}
     */
    get meta() {
        const ret = wasm.watchlistresult_meta(this.__wbg_ptr);
        return Meta.__wrap(ret);
    }
    /**
     * @returns {PubkyAppWatchlist}
     */
    get watchlist() {
        const ret = wasm.watchlistresult_watchlist(this.__wbg_ptr);
        return PubkyAppWatchlist.__wrap(ret);
    }
}
if (Symbol.dispose) WatchlistResult.prototype[Symbol.dispose] = WatchlistResult.prototype.free;
exports.WatchlistResult = WatchlistResult;

/**
 * @param {string} user_id
 * @returns {string}
 */
function baseUriBuilder(user_id) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.baseUriBuilder(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}
exports.baseUriBuilder = baseUriBuilder;

/**
 * Builds a Blob URI of the form "pubky://<author_id>/pub/pubky.app/blobs/<blob_id>"
 * @param {string} author_id
 * @param {string} blob_id
 * @returns {string}
 */
function blobUriBuilder(author_id, blob_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(blob_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.blobUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.blobUriBuilder = blobUriBuilder;

/**
 * Builds a Bookmark URI of the form "pubky://<author_id>/pub/pubky.app/bookmarks/<bookmark_id>"
 * @param {string} author_id
 * @param {string} bookmark_id
 * @returns {string}
 */
function bookmarkUriBuilder(author_id, bookmark_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(bookmark_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.bookmarkUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.bookmarkUriBuilder = bookmarkUriBuilder;

/**
 * Builds a Feed URI of the form "pubky://<author_id>/pub/pubky.app/feeds/<feed_id>"
 * @param {string} author_id
 * @param {string} feed_id
 * @returns {string}
 */
function feedUriBuilder(author_id, feed_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(feed_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.feedUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.feedUriBuilder = feedUriBuilder;

/**
 * Builds a File URI of the form "pubky://<author_id>/pub/pubky.app/files/<file_id>"
 * @param {string} author_id
 * @param {string} file_id
 * @returns {string}
 */
function fileUriBuilder(author_id, file_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(file_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.fileUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.fileUriBuilder = fileUriBuilder;

/**
 * Builds a Follow URI of the form "pubky://<author_id>/pub/pubky.app/follows/<follow_id>"
 * @param {string} author_id
 * @param {string} follow_id
 * @returns {string}
 */
function followUriBuilder(author_id, follow_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(follow_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.followUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.followUriBuilder = followUriBuilder;

/**
 * Returns the list of valid MIME types for file attachments.
 *
 * This allows JavaScript consumers to validate file types before submission
 * without having to duplicate the list.
 *
 * # Example (TypeScript)
 *
 * ```typescript
 * import { get_valid_mime_types } from "pubky-app-specs";
 *
 * const validTypes = get_valid_mime_types();
 * const fileType = "image/png";
 * if (validTypes.includes(fileType)) {
 *   console.log("Valid file type!");
 * }
 * ```
 * @returns {any[]}
 */
function getValidMimeTypes() {
    const ret = wasm.getValidMimeTypes();
    var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
    return v1;
}
exports.getValidMimeTypes = getValidMimeTypes;

/**
 * Each FFI function:
 * - Accepts minimal fields in a JavaScript-friendly manner (e.g. strings, JSON).
 * - Creates the Rust model, sanitizes, and validates it.
 * - Generates the ID (if applicable).
 * - Generates the path (if applicable).
 * - Returns { json, id, path, url } or a descriptive error.
 * Returns validation limits as a JSON value for client-side use without a builder.
 * @returns {any}
 */
function getValidationLimits() {
    const ret = wasm.getValidationLimits();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.getValidationLimits = getValidationLimits;

/**
 * Builds a LastRead URI of the form "pubky://<author_id>/pub/pubky.app/last_read"
 * @param {string} author_id
 * @returns {string}
 */
function lastReadUriBuilder(author_id) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lastReadUriBuilder(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}
exports.lastReadUriBuilder = lastReadUriBuilder;

/**
 * Builds a Listing URI of the form "pubky://<seller_id>/pub/pubky.app/marketplace/v1/listings/<listing_id>"
 * @param {string} seller_id
 * @param {string} listing_id
 * @returns {string}
 */
function listingUriBuilder(seller_id, listing_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(seller_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(listing_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.listingUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.listingUriBuilder = listingUriBuilder;

/**
 * Builds a MarketplaceReview URI of the form "pubky://<author_id>/pub/pubky.app/marketplace/v1/reviews/<review_id>"
 * @param {string} author_id
 * @param {string} review_id
 * @returns {string}
 */
function marketplaceReviewUriBuilder(author_id, review_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(review_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.marketplaceReviewUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.marketplaceReviewUriBuilder = marketplaceReviewUriBuilder;

/**
 * Builds a Mute URI of the form "pubky://<author_id>/pub/pubky.app/mutes/<mute_id>"
 * @param {string} author_id
 * @param {string} mute_id
 * @returns {string}
 */
function muteUriBuilder(author_id, mute_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(mute_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.muteUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.muteUriBuilder = muteUriBuilder;

/**
 * Builds a private OrderReceipt URI of the form "pubky://<owner_id>/priv/pubky.app/marketplace/v1/receipts/<receipt_id>".
 *
 * Note the `/priv/` prefix: only the owner's own authenticated sessions can
 * read or write this URI; it is never watcher-indexed.
 * @param {string} owner_id
 * @param {string} receipt_id
 * @returns {string}
 */
function orderReceiptUriBuilder(owner_id, receipt_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(owner_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(receipt_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.orderReceiptUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.orderReceiptUriBuilder = orderReceiptUriBuilder;

/**
 * Parses and structurally validates a compact JWS order receipt
 * attestation, returning its claims as a plain JSON object. Does NOT
 * verify the signature — see `verifyOrderReceiptAttestation`.
 * @param {string} jws
 * @returns {any}
 */
function parseOrderReceiptAttestation(jws) {
    const ptr0 = passStringToWasm0(jws, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parseOrderReceiptAttestation(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.parseOrderReceiptAttestation = parseOrderReceiptAttestation;

/**
 * Parses and structurally validates a compact JWS purchase attestation,
 * returning its claims as a plain JSON object. Does NOT verify the
 * signature — see `verifyPurchaseAttestation`.
 * @param {string} jws
 * @returns {any}
 */
function parsePurchaseAttestation(jws) {
    const ptr0 = passStringToWasm0(jws, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parsePurchaseAttestation(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.parsePurchaseAttestation = parsePurchaseAttestation;

/**
 * Parses a Pubky URI and returns a strongly typed `ParsedUriResult`.
 *
 * This function wraps the internal ParsedUri ust parsing logic. It converts the result into a
 * strongly typed object that is easier to use in TypeScript.
 *
 * # Parameters
 *
 * - `uri`: A string slice representing the Pubky URI. The URI should follow the format:
 *   `pubky://<user_id>/pub/pubky.app/<resource>[/<id>]`.
 *
 * # Returns
 *
 * On success, returns a `ParsedUriResult` with:
 * - `user_id`: the parsed user ID,
 * - `resource`: a string (derived from the Display implementation of internal `Resource` enum),
 * - `resource_id`: an optional resource identifier (if applicable).
 *
 * On failure, returns a JavaScript error (`String`) containing an error message.
 *
 * # Example (TypeScript)
 *
 * ```typescript
 * import { parse_uri } from "pubky-app-specs";
 *
 * try {
 *   const result = parse_uri("pubky://user123/pub/pubky.app/posts/abc123");
 *   console.log(result.user_id);        // e.g. "user123"
 *   console.log(result.resource);    // e.g. "posts"
 *   console.log(result.resource_id);      // e.g. "abc123" or null
 * } catch (error) {
 *   console.error("Error parsing URI:", error);
 * }
 * ```
 * @param {string} uri
 * @returns {ParsedUriResult}
 */
function parse_uri(uri) {
    const ptr0 = passStringToWasm0(uri, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parse_uri(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ParsedUriResult.__wrap(ret[0]);
}
exports.parse_uri = parse_uri;

/**
 * Builds a Post URI of the form "pubky://<author_id>/pub/pubky.app/posts/<post_id>"
 * @param {string} author_id
 * @param {string} post_id
 * @returns {string}
 */
function postUriBuilder(author_id, post_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(post_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.postUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.postUriBuilder = postUriBuilder;

/**
 * Builds a ReviewResponse URI of the form "pubky://<responder_id>/pub/pubky.app/marketplace/v1/review_responses/<review_id>"
 * @param {string} responder_id
 * @param {string} review_id
 * @returns {string}
 */
function reviewResponseUriBuilder(responder_id, review_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(responder_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(review_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.reviewResponseUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.reviewResponseUriBuilder = reviewResponseUriBuilder;

/**
 * Builds a Shop URI of the form "pubky://<owner_id>/pub/pubky.app/marketplace/v1/shop.json"
 * @param {string} owner_id
 * @returns {string}
 */
function shopUriBuilder(owner_id) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(owner_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.shopUriBuilder(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}
exports.shopUriBuilder = shopUriBuilder;

/**
 * Builds a Tag URI of the form "pubky://<author_id>/pub/pubky.app/tags/<tag_id>"
 * @param {string} author_id
 * @param {string} tag_id
 * @returns {string}
 */
function tagUriBuilder(author_id, tag_id) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(author_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(tag_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.tagUriBuilder(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
exports.tagUriBuilder = tagUriBuilder;

/**
 * Builds an User URI of the form "pubky://<user_pubky_id>/pub/pubky.app/profile.json"
 * @param {string} user_id
 * @returns {string}
 */
function userUriBuilder(user_id) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.userUriBuilder(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}
exports.userUriBuilder = userUriBuilder;

/**
 * The full local verification recipe for one order receipt record: parses
 * the record (camelCase JSON) against the spec, parses its embedded
 * attestation, verifies the Ed25519 signature against the `iss` pubky, and
 * checks the claim bindings. Returns the verified claims. Whether `iss` is
 * a *trusted* attestor remains the caller's policy decision.
 * @param {any} receipt
 * @returns {any}
 */
function verifyOrderReceiptAttestation(receipt) {
    const ret = wasm.verifyOrderReceiptAttestation(receipt);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.verifyOrderReceiptAttestation = verifyOrderReceiptAttestation;

/**
 * The full local verification recipe for one review record: parses the
 * record (camelCase JSON) against the spec, parses its embedded
 * attestation, verifies the Ed25519 signature against the `iss` pubky, and
 * checks the claim bindings. Returns the verified claims. Whether `iss` is
 * a *trusted* attestor remains the caller's policy decision.
 * @param {any} review
 * @returns {any}
 */
function verifyPurchaseAttestation(review) {
    const ret = wasm.verifyPurchaseAttestation(review);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
exports.verifyPurchaseAttestation = verifyPurchaseAttestation;

/**
 * Builds a private Watchlist URI of the form "pubky://<owner_id>/priv/pubky.app/marketplace/v1/watchlist.json".
 *
 * Note the `/priv/` prefix: only the owner's own authenticated sessions can
 * read or write this URI; it is never watcher-indexed.
 * @param {string} owner_id
 * @returns {string}
 */
function watchlistUriBuilder(owner_id) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(owner_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.watchlistUriBuilder(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}
exports.watchlistUriBuilder = watchlistUriBuilder;
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg_Error_960c155d3d49e4c2: function(arg0, arg1) {
            const ret = Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_Number_32bf70a599af1d4b: function(arg0) {
            const ret = Number(arg0);
            return ret;
        },
        __wbg_String_8564e559799eccda: function(arg0, arg1) {
            const ret = String(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_bigint_get_as_i64_3d3aba5d616c6a51: function(arg0, arg1) {
            const v = arg1;
            const ret = typeof(v) === 'bigint' ? v : undefined;
            getDataViewMemory0().setBigInt64(arg0 + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_boolean_get_6ea149f0a8dcc5ff: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_debug_string_ab4b34d23d6778bd: function(arg0, arg1) {
            const ret = debugString(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_in_a5d8b22e52b24dd1: function(arg0, arg1) {
            const ret = arg0 in arg1;
            return ret;
        },
        __wbg___wbindgen_is_bigint_ec25c7f91b4d9e93: function(arg0) {
            const ret = typeof(arg0) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_function_3baa9db1a987f47d: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_52ff4ec04186736f: function(arg0) {
            const ret = arg0 === null;
            return ret;
        },
        __wbg___wbindgen_is_object_63322ec0cd6ea4ef: function(arg0) {
            const val = arg0;
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_6df3bf7ef1164ed3: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_29a43b4d42920abd: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_jsval_eq_d3465d8a07697228: function(arg0, arg1) {
            const ret = arg0 === arg1;
            return ret;
        },
        __wbg___wbindgen_jsval_loose_eq_cac3565e89b4134c: function(arg0, arg1) {
            const ret = arg0 == arg1;
            return ret;
        },
        __wbg___wbindgen_number_get_c7f42aed0525c451: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_7ed5322991caaec5: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_6b64449b9b9ed33c: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_call_14b169f759b26747: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.call(arg1);
            return ret;
        }, arguments); },
        __wbg_done_9158f7cc8751ba32: function(arg0) {
            const ret = arg0.done;
            return ret;
        },
        __wbg_entries_e0b73aa8571ddb56: function(arg0) {
            const ret = Object.entries(arg0);
            return ret;
        },
        __wbg_fromCodePoint_4592108dc134086a: function() { return handleError(function (arg0) {
            const ret = String.fromCodePoint(arg0 >>> 0);
            return ret;
        }, arguments); },
        __wbg_get_1affdbdd5573b16a: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_8360291721e2339f: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_unchecked_17f53dad852b9588: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_with_ref_key_6412cf3094599694: function(arg0, arg1) {
            const ret = arg0[arg1];
            return ret;
        },
        __wbg_instanceof_ArrayBuffer_7c8433c6ed14ffe3: function(arg0) {
            let result;
            try {
                result = arg0 instanceof ArrayBuffer;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Map_1b76fd4635be43eb: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Map;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_152ba1f289edcf3f: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_c3109d14ffc06469: function(arg0) {
            const ret = Array.isArray(arg0);
            return ret;
        },
        __wbg_isSafeInteger_4fc213d1989d6d2a: function(arg0) {
            const ret = Number.isSafeInteger(arg0);
            return ret;
        },
        __wbg_iterator_013bc09ec998c2a7: function() {
            const ret = Symbol.iterator;
            return ret;
        },
        __wbg_length_3d4ecd04bd8d22f1: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_9f1775224cf1d815: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_new_0c7403db6e782f19: function(arg0) {
            const ret = new Uint8Array(arg0);
            return ret;
        },
        __wbg_new_34d45cc8e36aaead: function() {
            const ret = new Map();
            return ret;
        },
        __wbg_new_682678e2f47e32bc: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_aa8d0fa9762c29bd: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_from_slice_b5ea43e23f6008c0: function(arg0, arg1) {
            const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_next_0340c4ae324393c3: function() { return handleError(function (arg0) {
            const ret = arg0.next();
            return ret;
        }, arguments); },
        __wbg_next_7646edaa39458ef7: function(arg0) {
            const ret = arg0.next;
            return ret;
        },
        __wbg_now_a9b7df1cbee90986: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_prototypesetcall_a6b02eb00b0f4ce2: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_pubkyappuserlink_new: function(arg0) {
            const ret = PubkyAppUserLink.__wrap(arg0);
            return ret;
        },
        __wbg_pubkyappuserlink_unwrap: function(arg0) {
            const ret = PubkyAppUserLink.__unwrap(arg0);
            return ret;
        },
        __wbg_set_3bf1de9fab0cd644: function(arg0, arg1, arg2) {
            arg0[arg1 >>> 0] = arg2;
        },
        __wbg_set_6be42768c690e380: function(arg0, arg1, arg2) {
            arg0[arg1] = arg2;
        },
        __wbg_set_fde2cec06c23692b: function(arg0, arg1, arg2) {
            const ret = arg0.set(arg1, arg2);
            return ret;
        },
        __wbg_value_ee3a06f4579184fa: function(arg0) {
            const ret = arg0.value;
            return ret;
        },
        __wbindgen_cast_0000000000000001: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000002: function(arg0) {
            // Cast intrinsic for `I64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_cast_0000000000000004: function(arg0) {
            // Cast intrinsic for `U64 -> Externref`.
            const ret = BigInt.asUintN(64, arg0);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./pubky_app_specs_bg.js": import0,
    };
}

const BlobResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_blobresult_free(ptr >>> 0, 1));
const BookmarkResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_bookmarkresult_free(ptr >>> 0, 1));
const FeedResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_feedresult_free(ptr >>> 0, 1));
const FileResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fileresult_free(ptr >>> 0, 1));
const FollowResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_followresult_free(ptr >>> 0, 1));
const LastReadResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_lastreadresult_free(ptr >>> 0, 1));
const ListingResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_listingresult_free(ptr >>> 0, 1));
const MarketplaceOrderReceiptResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_marketplaceorderreceiptresult_free(ptr >>> 0, 1));
const MarketplaceReviewResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_marketplacereviewresult_free(ptr >>> 0, 1));
const MetaFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_meta_free(ptr >>> 0, 1));
const MuteResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_muteresult_free(ptr >>> 0, 1));
const ParsedUriResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_parseduriresult_free(ptr >>> 0, 1));
const PostResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_postresult_free(ptr >>> 0, 1));
const PubkyAppBlobFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappblob_free(ptr >>> 0, 1));
const PubkyAppBookmarkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappbookmark_free(ptr >>> 0, 1));
const PubkyAppFeedFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappfeed_free(ptr >>> 0, 1));
const PubkyAppFeedConfigFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappfeedconfig_free(ptr >>> 0, 1));
const PubkyAppFileFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappfile_free(ptr >>> 0, 1));
const PubkyAppFollowFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappfollow_free(ptr >>> 0, 1));
const PubkyAppLastReadFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyapplastread_free(ptr >>> 0, 1));
const PubkyAppListingFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyapplisting_free(ptr >>> 0, 1));
const PubkyAppMarketplaceLocationFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappmarketplacelocation_free(ptr >>> 0, 1));
const PubkyAppMarketplaceOrderReceiptFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappmarketplaceorderreceipt_free(ptr >>> 0, 1));
const PubkyAppMarketplaceReviewFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappmarketplacereview_free(ptr >>> 0, 1));
const PubkyAppMoneyFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappmoney_free(ptr >>> 0, 1));
const PubkyAppMuteFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappmute_free(ptr >>> 0, 1));
const PubkyAppPostFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyapppost_free(ptr >>> 0, 1));
const PubkyAppPostEmbedFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyapppostembed_free(ptr >>> 0, 1));
const PubkyAppReviewRatingsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappreviewratings_free(ptr >>> 0, 1));
const PubkyAppReviewResponseFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappreviewresponse_free(ptr >>> 0, 1));
const PubkyAppShopFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappshop_free(ptr >>> 0, 1));
const PubkyAppTagFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyapptag_free(ptr >>> 0, 1));
const PubkyAppUserFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappuser_free(ptr >>> 0, 1));
const PubkyAppUserLinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappuserlink_free(ptr >>> 0, 1));
const PubkyAppWatchlistFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappwatchlist_free(ptr >>> 0, 1));
const PubkyAppWatchlistItemFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappwatchlistitem_free(ptr >>> 0, 1));
const PubkyAppWatchlistTombstoneFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyappwatchlisttombstone_free(ptr >>> 0, 1));
const PubkyIdFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyid_free(ptr >>> 0, 1));
const PubkySpecsBuilderFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pubkyspecsbuilder_free(ptr >>> 0, 1));
const ReviewResponseResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_reviewresponseresult_free(ptr >>> 0, 1));
const ShopResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_shopresult_free(ptr >>> 0, 1));
const TagResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_tagresult_free(ptr >>> 0, 1));
const UserResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_userresult_free(ptr >>> 0, 1));
const WatchlistResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_watchlistresult_free(ptr >>> 0, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    for (let i = 0; i < array.length; i++) {
        const add = addToExternrefTable0(array[i]);
        getDataViewMemory0().setUint32(ptr + 4 * i, add, true);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
function decodeText(ptr, len) {
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

const wasmPath = `${__dirname}/pubky_app_specs_bg.wasm`;
const wasmBytes = require('fs').readFileSync(wasmPath);
const wasmModule = new WebAssembly.Module(wasmBytes);
let wasm = new WebAssembly.Instance(wasmModule, __wbg_get_imports()).exports;
wasm.__wbindgen_start();
